import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { AuthGuard } from './auth.service';
import { SignupComponent } from './signup/signup.component';
import { EmailComponent } from './email/email.component';
import {MembersComponent} from './members/members.component';
import {DashboardComponent} from './dashboard/dashboard.component';
import {UserdetailsComponent} from './userdetails/userdetails.component';
import {SearchComponent} from  './search/search.component';
import {PreferenceComponent} from './preference/preference.component';
import {ImageUploadComponent} from './image-upload/image-upload.component';
import{ProfileListingComponent} from './profile-listing/profile-listing.component'
const routes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
  { path: 'signup', component: SignupComponent },
  { path: 'login-email', component: EmailComponent},
  {path: 'members', component: MembersComponent, canActivate: [AuthGuard]},
  {path: 'dashboard', component: DashboardComponent, canActivate: [AuthGuard]},
  {path: 'userdetails', component: UserdetailsComponent, canActivate: [AuthGuard]},
  {path: 'search', component: SearchComponent, canActivate: [AuthGuard]},
  {path: 'preference', component: PreferenceComponent, canActivate: [AuthGuard]},
  {path: 'photoupload', component: ImageUploadComponent, canActivate: [AuthGuard]},
  {path: 'profile/:id', component: ProfileListingComponent, canActivate: [AuthGuard]}

];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

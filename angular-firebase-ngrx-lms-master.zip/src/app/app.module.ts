import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MaterialModule, MdInputModule, MdButtonModule, MdCardModule, MdMenuModule, MdToolbarModule, MdIconModule, MdAutocompleteModule, MdGridListModule, MdDatepickerModule, MdNativeDateModule, MdSelectModule} from '@angular/material';
import { MaterializeModule } from "angular2-materialize";
import { DatePipe } from  '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import {ReactiveFormsModule} from '@angular/forms';
import { HttpModule } from '@angular/http';
import { AngularFireModule } from 'angularfire2';
import { AppRoutingModule } from './app-routing.module';
import { Ng2FilterPipeModule } from 'ng2-filter-pipe';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import {ImageCropperComponent, ImageCropperModule, CropperSettings, Bounds} from 'ng2-img-cropper';
import { Md2Module }  from 'md2';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { EmailComponent } from './email/email.component';
import { SignupComponent } from './signup/signup.component';
import { MembersComponent } from './members/members.component';
import { AuthGuard } from './auth.service';
import { DashboardComponent } from './dashboard/dashboard.component';
import { UserdetailsComponent } from './userdetails/userdetails.component';
import { MainmenuComponent } from './mainmenu/mainmenu.component';
import { SearchComponent } from './search/search.component';
import { PreferenceComponent } from './preference/preference.component';
import { ImageUploadComponent } from './image-upload/image-upload.component';
import { ProfileListingComponent } from './profile-listing/profile-listing.component';
import { ShortlistComponent } from './shortlist/shortlist.component';



export const firebaseConfig = {
  apiKey: "AIzaSyD5FXScnki-Zn5giQauvZMXx2vNu8Ni7y0",
  authDomain: "design-822b3.firebaseapp.com",
  databaseURL: "https://design-822b3.firebaseio.com",
  projectId: "design-822b3",
  storageBucket: "design-822b3.appspot.com",
  messagingSenderId: "454181967546"
};


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    EmailComponent,
    SignupComponent,
    MembersComponent,
    DashboardComponent,
    UserdetailsComponent,
    MainmenuComponent,
    SearchComponent,
    PreferenceComponent,
    ImageUploadComponent,
    ProfileListingComponent,
    ShortlistComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    Ng2FilterPipeModule,
    MaterialModule,
    MdInputModule,
    MdButtonModule,
    MdMenuModule,
    MdCardModule,
    MdToolbarModule,
    MdIconModule,
    MdAutocompleteModule,
    MdGridListModule,
    MdDatepickerModule,
    MdNativeDateModule,
    MdSelectModule,
    MaterializeModule,
    InfiniteScrollModule,
    FormsModule,
    ReactiveFormsModule,
    HttpModule,
    AppRoutingModule,
    Md2Module,
    ImageCropperModule,
    AngularFireModule.initializeApp(firebaseConfig)
  ],
  providers: [AuthGuard, DatePipe],
  bootstrap: [AppComponent]
})
export class AppModule { }

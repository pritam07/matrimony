import { Component, OnInit, OnChanges, ViewEncapsulation } from '@angular/core';
import {AngularFire, AuthProviders, AuthMethods, FirebaseListObservable, FirebaseObjectObservable} from "angularfire2";
import {Router} from '@angular/router';
import { moveIn, fallIn } from '../router.animations';
import {FormBuilder, FormGroup, FormControl, Validator, Validators} from '@angular/forms';
import { DatePipe } from  '@angular/common';
import 'rxjs/add/operator/startWith';
import 'rxjs/add/operator/map';
import { Subject } from 'rxjs/Subject';
import {MdSnackBar} from '@angular/material';
import * as firebase from 'firebase';
import {validate} from "codelyzer/walkerFactory/walkerFn";
import {getOrderObservables} from "angularfire2/database";
import {ImageCropperComponent, CropperSettings, Bounds} from 'ng2-img-cropper';
@Component({
  selector: 'app-userdetails',
  templateUrl: './userdetails.component.html',
    encapsulation: ViewEncapsulation.None,
  styleUrls: ['./userdetails.component.scss'],
  animations: [moveIn(), fallIn()],
  host: {'[@moveIn]': ''}
})
export class UserdetailsComponent implements OnInit, OnChanges {
  items: FirebaseListObservable<any>;
  itemsFilterValue: FirebaseListObservable<any>;
  masterDetailsValues: FirebaseObjectObservable<any>;
  userDetailsForm: FormGroup;
  firstName: string;
  lastName: string;
  gender: string;
  dob: any;
  states: any;
  filterSubject: Subject<any>;
  emailAdress: any;
  stateName: any;
  cityList: any;
  minDate: any;
  maxDate: any;
  myFilter: any;
  countryList: any;
  country: any;
  createdby: any;
  createdbyList: any;
  religions: any;
  religion: any;
  genders: any;
  mothertongue: any;
  motherTongueList: any;
  casteList: any;
  caste: any;
  maritialstatus : any;
  maritialStatusList : any;
  profileimage: any;
  storageRef : any;
  folder: any;
  imgData:any;
  cropperSettings:CropperSettings;
  croppedWidth:number;
  croppedHeight:number;
  setImg: any = true;
  stateCtrl: FormControl;
  imageUploadMessage: any;
  path: any
  imageFileName: any;
  cropSetBtn: any = false;
  filteredstateName: any;
  dbRef: any;
  userId: any;
  cropper:ImageCropperComponent;
  filterAutocomplete: any;
  generateTargetFunction: any;
  

  constructor(public af: AngularFire, private fb: FormBuilder, private datePipe: DatePipe, public snackBar: MdSnackBar) {
    this.userDetailsForm = this.fb.group({
      'firstName': [null, Validators.required],
      'lastName': [null, Validators.required],
      'gender': [null, Validators.required,],
      'dob': [null, Validators.required],
      'country': [null, Validators.required],
      'states': [null, Validators.required],
      'city': [null, Validators.required],
      'createdby': [null, Validators.required],
      'religion': [null, Validators.required],
      'mothertongue':  [null, Validators.required],
      'caste': [null, Validators.required],
      'maritialstatus': [null, Validators.required]
    });

    this.cropperSettings = new CropperSettings();
    this.cropperSettings.width = 200;
    this.cropperSettings.height = 200;

    this.cropperSettings.croppedWidth = 200;
    this.cropperSettings.croppedHeight = 200;

    this.cropperSettings.canvasWidth = 500;
    this.cropperSettings.canvasHeight = 300;

    this.cropperSettings.minWidth = 10;
    this.cropperSettings.minHeight = 10;

    this.cropperSettings.rounded = false;
    this.cropperSettings.keepAspect = false;

    this.cropperSettings.cropperDrawSettings.strokeColor = 'rgba(255,255,255,1)';
    this.cropperSettings.cropperDrawSettings.strokeWidth = 2;
    this.cropperSettings.croppingClass = 'croppClass';
    this.cropperSettings.cropperClass = 'croppSetClass';
    this.imgData = {};




    this.masterDetailsValues =  af.database.object('/masterdetails');

    this.stateCtrl = new FormControl();
    this.storageRef = firebase.storage().ref();

/*    this.filteredstateName = this.stateCtrl.valueChanges
      .startWith(null).map(name => this.filterstateName(name));*/
    this.items = af.database.list('/users');

    this.masterDetailsValues.subscribe(stateVal => {
        this.countryList = stateVal.country;

 /*     this.filterAutocomplete = function (filterObj) {
        return this.stateCtrl.valueChanges
          .startWith(null).map(filstate => filstate && typeof filstate === 'object' ? filstate.viewValue : filstate)
          .map(viewValue => viewValue ? filterObj.filter(option => { new RegExp(`^${viewValue}`, 'gi').test(option.viewValue)}) : filterObj.slice());

      };*/
      this.filterAutocomplete = function (filterObj, controlName) {
       return this.userDetailsForm.controls[controlName].valueChanges
          .startWith(null).map(filstate => filstate && typeof filstate === 'object' ? filstate.viewValue : filstate)
          .map(viewValue => viewValue ? filterObj.filter(option => { return new RegExp(`^${viewValue}`, 'gi').test(option.viewValue)}) : filterObj.slice());

      };

     // this.filteredstateName = this.filterAutocomplete(this.countryList);

      this.countryList = this.filterAutocomplete(this.countryList, 'country');
      this.religions = this.filterAutocomplete(stateVal.religion, 'religion');
      this.createdbyList = stateVal.createdby;
      this.genders = stateVal.gender;
      this.motherTongueList = this.filterAutocomplete(stateVal.mothertongue, 'mothertongue');
      this.casteList = this.filterAutocomplete(stateVal.caste, 'caste');
      this.maritialStatusList = stateVal.maritialstatus;


      /*this.filteredstateName = this.stateCtrl.valueChanges
       .startWith(null).map(filstate => filstate && typeof filstate === 'object' ? filstate.value : filstate)
       .map(value => value ? this.filterstateName(value) : this.stateName.slice());*/
      this.userDetailsForm.controls['gender'].valueChanges.subscribe(newGender =>{
        this.userDetailsForm.controls['dob'].reset(null, { emitEvent: false });

        if (newGender.value == 'female') {
          this.myFilter = (d: Date) => d.getFullYear() > d.getFullYear() - 18;
          //alert(new Date().getFullYear() - 18);

          this.minDate = new Date(new Date().setFullYear((new Date().getUTCFullYear() - 18)));

          // d.setFullYear(this.minDate);

        }
        else if (newGender.value == 'male') {
          this.minDate = new Date(new Date().setFullYear((new Date().getUTCFullYear() - 21)));
        }
      });

      this.userDetailsForm.controls['country'].valueChanges.subscribe(newCountry =>{
        if(newCountry){
          let filterArrycountry = (stateVal.states.filter(task => { return task[newCountry.value]}));
          this.userDetailsForm.controls['states'].reset(null, { emitEvent: false });
          this.userDetailsForm.controls['city'].reset(null, { emitEvent: false });
          if(filterArrycountry.length > 0){
            this.stateName = filterArrycountry[0][newCountry.value];
            this.stateName = this.filterAutocomplete(this.stateName, 'states');
          }
          else {
            this.userDetailsForm.controls['states'].reset(null, { emitEvent: false });
            this.stateName = null;
            this.userDetailsForm.controls['city'].reset(null, { emitEvent: false });
            this.cityList = null;
          }
        }

        else {
          this.userDetailsForm.controls['states'].reset(null, { emitEvent: false });
          this.stateName = null;
          this.userDetailsForm.controls['city'].reset(null, { emitEvent: false });
          this.cityList = null;
        }

      });

      this.userDetailsForm.controls['states'].valueChanges.subscribe(newStates =>{
        if(newStates){
          let filterArryState = (stateVal.city.filter(task => { return task[newStates.value]}));
          this.userDetailsForm.controls['city'].reset(null, { emitEvent: false });
          if(filterArryState.length > 0) {
            this.cityList =  filterArryState[0][newStates.value];
            this.cityList = this.filterAutocomplete(this.cityList, 'city');
          }
          else {
            this.userDetailsForm.controls['city'].reset(null, { emitEvent: false });
            this.cityList = null;
            //this.userDetailsForm.controls['city'].disable({onlySelf: true, emitEvent: false});
          }
        }
        else {
          this.userDetailsForm.controls['city'].reset(null, { emitEvent: false });
          this.cityList = null;
        }

      });

    /*  this.userDetailsForm.valueChanges.subscribe(stateData =>{
        if(stateData.country){
          let filterArrycountry = (stateVal.states.filter(task => { return task[stateData.country.value]}));
          this.userDetailsForm.controls['country'].valueChanges.subscribe(newcityVal =>{
            this.userDetailsForm.controls['states'].reset(null, { emitEvent: false });
            this.userDetailsForm.controls['city'].reset(null, { emitEvent: false });
          });
          if(filterArrycountry.length > 0){
            this.stateName = filterArrycountry[0][stateData.country.value];
            this.stateName = filterAutocomplete(this.stateName, 'states');
            if(stateData.states) {
            let filterArryState = (stateVal.city.filter(task => { return task[stateData.states.value]}));
              this.userDetailsForm.controls['states'].valueChanges.subscribe(newcityVal =>{
                this.userDetailsForm.controls['city'].reset(null, { emitEvent: false });
              });
            if(filterArryState.length > 0) {
              this.cityList =  filterArryState[0][stateData.states.value];
              this.cityList = this.filterAutocomplete(this.cityList, 'city');

            }
              else {
                this.userDetailsForm.controls['city'].reset(null, { emitEvent: false });
                this.cityList = null;
                //this.userDetailsForm.controls['city'].disable({onlySelf: true, emitEvent: false});
              }

            }
            else {
              this.userDetailsForm.controls['city'].reset(null, { emitEvent: false });
              this.cityList = null;
            }


          }
          else {
            this.userDetailsForm.controls['states'].reset(null, { emitEvent: false });
            this.stateName = null;
            this.userDetailsForm.controls['city'].reset(null, { emitEvent: false });
            this.cityList = null;
          }
        }
        else {
          this.userDetailsForm.controls['states'].reset(null, { emitEvent: false });
          this.stateName = null;
          this.userDetailsForm.controls['city'].reset(null, { emitEvent: false });
          this.cityList = null;
        }
/!*        if(stateData.stateName) {
          if(stateVal.city.hasOwnProperty(stateData.stateName.value)){
              this.cityList = stateVal.city[stateData.stateName.value];
              this.cityList = this.filterAutocomplete(this.cityList);

          }
          else {
            //this.userDetailsForm.controls['city'].setValue('');
            this.userDetailsForm.controls['city'].reset(null, { emitEvent: false });
            this.cityList = null;
            //this.userDetailsForm.controls['city'].disable({onlySelf: true, emitEvent: false});
          }

      }*!/
      if(stateData.gender) {
        if (stateData.gender.value == 'female') {
          this.myFilter = (d: Date) => d.getFullYear() > d.getFullYear() - 18;
          //alert(new Date().getFullYear() - 18);

          this.minDate = new Date(new Date().setFullYear((new Date().getUTCFullYear() - 18)));

          // d.setFullYear(this.minDate);

        }
        else if (stateData.gender.value == 'male') {
          this.minDate = new Date(new Date().setFullYear((new Date().getUTCFullYear() - 21)));
        }
      }
      });*/
      console.log(JSON.stringify(this.stateName));
    });
  };

  /*filterstateName(value: any) {
    alert(this.stateName);
    return this.stateName.filter(option => new RegExp(`^${value}`, 'gi').test(option.value));
  };*/

  displayFn(filstate: any): string {
    return filstate ? filstate.viewValue : filstate;
  };
  cropped(bounds:Bounds) {
    this.croppedHeight =bounds.bottom-bounds.top;
    this.croppedWidth = bounds.right-bounds.left;
    this.cropSetBtn = true;
  }

/*  fileChangeListener($event) {
    var image:any = new Image();
    var file:File = $event.target.files[0];
    var myReader:FileReader = new FileReader();
    var that = this;
    myReader.onloadend = function (loadEvent:any) {
      image.src = loadEvent.target.result;
      that.cropper.setImage(image);

    };

    myReader.readAsDataURL(file);
  }*/
  submit(formObj){
    this.dbRef = firebase.database().ref('users');
    const newDbRef = firebase.database().ref('users');

    let getTDateTime = this.datePipe.transform(new Date(), 'short');
    let getKey = null;
    let pushObj = {};
    let setObj = {};
    let i = 0;
    if(this.imageUploadMessage != null && this.path && this.imageFileName){
      formObj.userImage = [];
      formObj.userImage.push({path: this.path, profileimage : this.imageFileName});

    }
    this.af.auth.subscribe(val =>{
      this.emailAdress = val.auth.email;
      this.userId = val.auth.uid;
    });

    formObj.uid = this.userId;
    formObj.email = this.emailAdress;
    formObj.age = new Date().getFullYear() - formObj.dob.getFullYear();
    formObj.dob = this.datePipe.transform(formObj.dob, 'shortDate');
    this.itemsFilterValue =  this.af.database.list('/users', {
      preserveSnapshot: true,
      query: {
        orderByChild: 'email',
        equalTo: this.emailAdress
      }
    });

    this.dbRef.orderByChild('uid').equalTo(this.userId).once('value', function (val) {

      if(val.val() == null){

        if(formObj) {
          formObj.createdOn = getTDateTime;
          let genDbRef= firebase.database().ref('users');
          formObj.sourceid = "IN123";
          formObj.targetid = "123" ;
          let generateSourceID = function () {
            formObj.sourceid = "IN" + Math.floor((Math.random() * 1000000000) + 1);
            generateSourceFunction();
            /*formObj.sourceid = "IN" + Math.floor((Math.random() * 1000000000) + 1);*/
          };

            var generateSourceFunction = function () {
              genDbRef.orderByChild('sourceid').equalTo(formObj.sourceid).once('value', function (sourceVal) {

                if (sourceVal.val() == null) {

                   var generateTargetFunction = function () {
                    formObj.targetid = Math.floor((Math.random() * 1000000000) + 1);
                    genDbRef.orderByChild('targetid').equalTo(formObj.targetid).once('value', function (targetVal) {
                     if (targetVal.val() == null) {
                        for (let key in formObj) {
                          if (formObj.hasOwnProperty(key)) {
                            if (formObj[key]) {
                              pushObj[key] = formObj[key];
                            }
                          }
                        }
                        getKey = newDbRef.push(pushObj).key;
                      } else {
                        generateTargetFunction();
                      }

                    });

                  };
                  generateTargetFunction();

                }
                else {
                  generateSourceID();
                }

              });
            };

            generateSourceFunction();



        }

      }
      else if(val.val() != null){
        formObj.updatedOn = getTDateTime;
        for (let uniqueKey in val.val()) {
          getKey = uniqueKey;
        }
        for (let key in formObj) {

          if (formObj.hasOwnProperty(key)) {
            console.log(formObj[key]);
            if(formObj[key]) {
              setObj[key] = formObj[key];
            }
          }
        }
        let updateRef:any =  firebase.database().ref('users/' + getKey);

        for(let dbKey in setObj) {
          updateRef.update({[dbKey]: setObj[dbKey]});
        }

      }
    });

  /*  this.itemsFilterValue.subscribe(val => {
      if(val.length == 0){
        formObj.createdOn = this.datePipe.transform(new Date(), 'fullDate');
        this.items.push(formObj);
      } else{
        val.forEach(val => {
          alert('2');
          //console.log(val.key);
         formObj.updatedOn =  this.datePipe.transform(new Date(), 'fullDate');
         alert(val.key);
         this.items.update(val.key, formObj);
        });

        //this.items.update(this.itemsFilterValue.$ref., formObj);
      }

    });*/

   /* this.items.subscribe(snapshot => {
      if(snapshot.exists()) {
        alert(JSON.stringify(snapshot.val()));
        //object exists
      } else {

      }
    });*/

  }
/*  previewImage(uloadImgEvent){
    this.folder =  this.af.auth.getAuth().auth.uid;
   // var fileUpload = document.getElementById("fileUpload");
    console.log(uloadImgEvent.target.value);
    let storageRef = firebase.storage().ref();
    //this.storageRef.put(uloadImgEvent.target.value);
    for (let selectedFile of [(<HTMLInputElement>document.getElementById('imageUpload')).files[0]]) {
      console.log(selectedFile);
      let path = `/${this.folder}/${selectedFile.name}`;
      let iRef = storageRef.child(path);
      iRef.put(selectedFile).then((snapshot) => {
        alert('1');
      //  console.log('Uploaded a blob or file! Now storing the reference at',`/${this.folder}/images/`);
       // af.database.list(`/${folder}/images/`).push({ path: path, filename: selectedFile.name })
      });
    }
  }*/
  setImage(){
    this.setImg = false;

    this.folder =  this.af.auth.getAuth().auth.uid;
    // var fileUpload = document.getElementById("fileUpload");

    let storageRef = firebase.storage().ref();
    //this.storageRef.put(uloadImgEvent.target.value);
    for (let selectedFile of [(<HTMLInputElement>document.querySelector('#getImageID span input')).files[0]]) {
      console.log(selectedFile);
      this.path = `/${this.folder}/${selectedFile.name}`;
      this.imageFileName = selectedFile.name;
      //let imageBase64 = "image base64 data";
/*      let blob = new Blob([this.imgData.image], {type: 'image/jpg'});
      let file = new File([blob], selectedFile.name);
      let metadata = {
        contentType: 'image/jpeg',
      };
      alert(JSON.stringify(file));*/
      let iRef = storageRef.child(this.path);
      iRef.putString(this.imgData.image, 'data_url').then((snapshot) => {
        this.snackBar.open('Uploaded Successfully', 'Close', {
          duration: 1500
        });

        //  console.log('Uploaded a blob or file! Now storing the reference at',`/${this.folder}/images/`);
        // af.database.list(`/${folder}/images/`).push({ path: path, filename: selectedFile.name })
      });
    }
  }
  changeImage(){
    this.imgData.image = null;
    this.setImg = true;
  }
  ngOnChanges(){

  }

  ngOnInit() {


  }
/*  filterstateName(val: string) {
    //alert(this.stateName);
    return val ? this.stateName.filter(s => new RegExp(`^${val}`, 'gi').test(s))
      : this.stateName;
  }*/
}

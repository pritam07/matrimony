import { Component, OnInit, OnChanges, ViewEncapsulation } from '@angular/core';
import {AngularFire, AuthProviders, AuthMethods, FirebaseListObservable, FirebaseObjectObservable} from "angularfire2";
import {Router} from '@angular/router';
import { moveIn, fallIn } from '../router.animations';
import {FormBuilder, FormGroup, FormControl, Validator, Validators} from '@angular/forms';
import { DatePipe } from  '@angular/common';
import 'rxjs/add/operator/startWith';
import 'rxjs/add/operator/map';
import { Subject } from 'rxjs/Subject';
import {MdSnackBar} from '@angular/material';
import * as firebase from 'firebase';
import {validate} from "codelyzer/walkerFactory/walkerFn";
import {getOrderObservables} from "angularfire2/database";
import {isUndefined} from "util";
@Component({
  selector: 'app-preference',
  templateUrl: './preference.component.html',
  encapsulation: ViewEncapsulation.None,
  styleUrls: ['./preference.component.scss']
})
export class PreferenceComponent implements OnInit {
  isRequired = false;
  isDisabled = false;
  tag: any;
  newtags: any;
  formData: any = {};
  user: any = {};
  tags: any;
  castes: any;
  religions: any;
  familyincomes: any;
  familytypes: any;
  cities: any;
  industries: any;
  occupations: any;
  smokings: any;
  mothertongues: any;
  maritialStatus: any;
  fromAge: any = [];
  toAge: any = [];
  drinkings: any;
  foodHabits: any;
  incomes: any;
  gones: any;
  educations: any;
  userId: any;
  items: FirebaseListObservable<any>;
  itemsObservalbel: FirebaseObjectObservable<any>;
  itemsFilterValue: FirebaseListObservable<any>;
  masterDetailsValues: FirebaseObjectObservable<any>;
  emailAdress: any;
  preferenceVal: any;
  pushModel: any = {};
  preferenceUpdate: any;
  getKey: string;
  dbRef: any;
  constructor(public af: AngularFire, private fb: FormBuilder, private datePipe: DatePipe) {
    this.masterDetailsValues =  af.database.object('/masterdetails');

    this.masterDetailsValues.subscribe(masterDetails => {
      this.cities = masterDetails.citylist;
      this.cities.unshift({value: null, viewValue: "Do not matter"});
      this.castes = masterDetails.caste;
      this.castes.unshift({value: null, viewValue: "Do not matter"});
      this.religions = masterDetails.religion;
      this.religions.unshift({value: null, viewValue: "Do not matter"});
      this.familyincomes = masterDetails.familyincome;
      this.familyincomes.unshift({value: null, viewValue: "Do not matter"});
      this.familytypes = masterDetails.familytype;
      this.familytypes.unshift({value: null, viewValue: "Do not matter"});
      this.industries = masterDetails.industry;
      this.industries.unshift({value: null, viewValue: "Do not matter"});
      this.occupations = masterDetails.occupation;
      this.occupations.unshift({value: null, viewValue: "Do not matter"});
      this.smokings = masterDetails.smoking;
      this.smokings.unshift({value: null, viewValue: "Do not matter"});
      this.mothertongues= masterDetails.mothertongue;
      this.mothertongues.unshift({value: null, viewValue: "Do not matter"});
      this.maritialStatus = masterDetails.maritialstatus;
      this.maritialStatus.unshift({value: null, viewValue: "Do not matter"});
      this.drinkings = masterDetails.drinking;
      this.drinkings.unshift({value: null, viewValue: "Do not matter"});
      this.foodHabits = masterDetails.foodHabits;
      this.foodHabits.unshift({value: null, viewValue: "Do not matter"});
      this.incomes = masterDetails.income;
      this.incomes.unshift({value: null, viewValue: "Do not matter"});
      this.gones = masterDetails.gone;
      this.gones.unshift({value: null, viewValue: "Do not matter"});
      this.educations = masterDetails.education;
      this.educations.unshift({value: null, viewValue: "Do not matter"});
      console.log(JSON.stringify(this.castes));
      for(let i = 18; i < 61; i++){
        this.fromAge.push(i);
        this.toAge.push(i);
      }
    });
    this.items = af.database.list('/preference');
    this.af.auth.subscribe(val =>{
      this.userId = val.auth.uid;
      this.emailAdress = val.auth.email;
    });
    this.itemsFilterValue =  this.af.database.list('/preference', {
      preserveSnapshot: true,
      query: {
        orderByChild: 'uid',
        equalTo: this.userId
      }
    });


   // this.itemsFilterValue =  this.af.database.list('/preference');

  }



  ngOnInit() {
  }
  multiChange(changeValue){
    alert(changeValue);
  }
  save(model, isValid){
    console.log('save');
    model.uid = this.userId;
    model.email = this.emailAdress;
    var getKey = null;
    var pushObj = {};
    var setObj = {};
    var getTDateTime = this.datePipe.transform(new Date(), 'short');
    this.dbRef = firebase.database().ref('preference');
    const newDbRef = firebase.database().ref('preference');

    this.dbRef.orderByChild('uid').equalTo(this.userId).once('value', function (val) {

     // this.preferenceVal = JSON.parse(JSON.stringify(val));
      //this.preferenceVal = val.val();

     /* alert(this.preferenceVal.length);
      alert(this.preferenceVal);*/

        if(val.val() == null){

          /*alert(this.datePipe.transform(new Date(), 'short'));
          model.createdOn = this.datePipe.transform(new Date(), 'short');*/
          if(model){
            console.log(model);
            model.createdOn = getTDateTime;
            for (let key in model) {
              if (model.hasOwnProperty(key)) {
                if (model[key]) {
                  pushObj[key] = model[key];
                }
              }
            }
            //console.log(JSON.stringify(this.pushModel));
            getKey = newDbRef.push(pushObj).key;
          }


        }
        else if(val.val() != null) {

          /*model.updatedOn = this.datePipe.transform(new Date(), 'short');*/
          model.updatedOn = getTDateTime;
          for (let uniqueKey in val.val()) {
            getKey = uniqueKey;
          }

          // this.itemsObservalbel =  this.af.database.object('/preference/' + firebaseKey);

          //  this.itemsObservalbel.set(model);
          for (let key in model) {

            if (model.hasOwnProperty(key)) {
              console.log(model[key]);
              if(model[key]) {
                setObj[key] = model[key];
                /*if(typeof model[key] == 'string'){
                 this.items.update(key, [model[key]]);
                 }
                 else if(typeof model[key] == 'object'){
                 this.itemsObservalbel.set(model[key]);
                 }*/

              }
            }
          }
          console.log(setObj);
          /* this.preferenceUpdate = {};
           this.preferenceUpdate['preference/'+firebaseKey] = this.pushModel;*/
          let updateRef:any =  firebase.database().ref('preference/' + getKey);

          for(let dbKey in setObj) {
            updateRef.update({[dbKey]: setObj[dbKey]});
          }

          //ref.set(this.pushModel);
          //ref.update(this.pushModel);
        }

    });



  }
}

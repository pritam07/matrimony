import { Injectable } from '@angular/core';
import { Component, OnInit, OnChanges, ViewEncapsulation, ViewChild, Type } from '@angular/core';
import {AngularFire, AuthProviders, AuthMethods, FirebaseListObservable, FirebaseObjectObservable} from "angularfire2";
import {Router} from '@angular/router';
import { moveIn, fallIn } from '../../router.animations';
import {FormBuilder, FormGroup, FormControl, Validator, Validators} from '@angular/forms';
import { DatePipe } from  '@angular/common';
import 'rxjs/add/operator/startWith';
import 'rxjs/add/operator/map';
import { Subject } from 'rxjs/Subject';
import {MdSnackBar} from '@angular/material';
import * as firebase from 'firebase';
import {validate} from "codelyzer/walkerFactory/walkerFn";
import {getOrderObservables} from "angularfire2/database";
import {ImageCropperComponent, CropperSettings, Bounds} from 'ng2-img-cropper';

@Injectable()
export class UploadService {
  cropperSettings:CropperSettings;
  croppedWidth:number;
  croppedHeight:number;
  emailAdress: any;
  userId: any;
  progressOne: any;
  constructor(private af: AngularFire) {
    this.cropperSettings = new CropperSettings();
    this.cropperSettings.width = 350;
    this.cropperSettings.height = 350;

    this.cropperSettings.croppedWidth = 350;
    this.cropperSettings.croppedHeight = 350;

    this.cropperSettings.canvasWidth = 500;
    this.cropperSettings.canvasHeight = 300;

    this.cropperSettings.minWidth = 10;
    this.cropperSettings.minHeight = 10;

    this.cropperSettings.rounded = false;
    this.cropperSettings.keepAspect = false;

    this.cropperSettings.cropperDrawSettings.strokeColor = 'rgba(255,255,255,1)';
    this.cropperSettings.cropperDrawSettings.strokeWidth = 2;
    this.cropperSettings.croppingClass = 'croppClass';
    this.cropperSettings.cropperClass = 'croppSetClass';

  }

  private basePath:string = '/uploads';
  uploads: FirebaseListObservable<any>;
  pushUpload(upload: any, userid, filename, progress, getKey, isLoaded) {
    let storageRef = firebase.storage().ref();
    let uploadTask = storageRef.child(`${userid}/${filename}`).putString(upload, 'data_url');
    return uploadTask.on(firebase.storage.TaskEvent.STATE_CHANGED,
      (snapshot) =>  {
        // upload in progress
        this.progressOne = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
        console.log( this.progressOne);
        let pushThat = this;
        setTimeout(function () {
          if(pushThat.progressOne == 100){
            isLoaded = false;
          }
        }, 500);



      },
      (error) => {
        // upload failed
        console.log(error);
      },
      () => {
        // upload success
        let thisimageOneUrl: object = {};

        thisimageOneUrl['url'] = `/${userid}/${filename}`;
        thisimageOneUrl['name'] = filename;
        this.saveFileData(thisimageOneUrl, getKey);
      }
    );
  }

  imageUpload(upload, userid, filename){
    let storageRef = firebase.storage().ref();
    let uploadTask = storageRef.child(`${userid}/${filename}`).putString(upload, 'data_url');
    return uploadTask.on(firebase.storage.TaskEvent.STATE_CHANGED);
  }

  // Writes the file details to the realtime db
  saveFileData(uploadObj: any, getKey) {
    let currentDbref = firebase.database().ref('users/' + getKey).child('profileImage');
    for(let dbKey in uploadObj) {
      currentDbref.update({[dbKey]: uploadObj[dbKey]});
    }

   // this.db.list(`${this.basePath}/`).push(upload);
  }


}

import { Component, OnInit, OnChanges, ViewEncapsulation, ViewChild, Type } from '@angular/core';
import {AngularFire, AuthProviders, AuthMethods, FirebaseListObservable, FirebaseObjectObservable} from "angularfire2";
import {Router} from '@angular/router';
import { moveIn, fallIn } from '../router.animations';
import {FormBuilder, FormGroup, FormControl, Validator, Validators} from '@angular/forms';
import { DatePipe } from  '@angular/common';
import 'rxjs/add/operator/startWith';
import 'rxjs/add/operator/map';
import { Subject } from 'rxjs/Subject';
import {MdSnackBar} from '@angular/material';
import * as firebase from 'firebase';
import {validate} from "codelyzer/walkerFactory/walkerFn";
import {getOrderObservables} from "angularfire2/database";
import {ImageCropperComponent, CropperSettings, Bounds} from 'ng2-img-cropper';
import { UploadService } from './shared/upload.service';


@Component({
  selector: 'app-image-upload',
  templateUrl: './image-upload.component.html',
  encapsulation: ViewEncapsulation.None,
  styleUrls: ['./image-upload.component.scss'],
  providers: [UploadService]
})
export class ImageUploadComponent implements OnInit {
  //Cropper 1 data
  data1:any;
  cropperSettings:CropperSettings;
  croppedWidth:number;
  croppedHeight:number;
  imgOne: any = {};
  imgTwo: any = {};
  imgThree: any = {};
  imgFour: any = {};
  userFolder: any;
  emailAdress: any;
  userId: any;
  storageRef: any;
  path: any;
  //Cropper 2 data
  data2:any;
  cropperSettings2:CropperSettings;
  picNameOne: any;
  picNameTwo: any;
  picNameThree: any;
  picNameFour: any;
  uploadImageOne: any;
  upload: any;
  isUploadOne: any = true;
  isUploadTwo: any = true;
  isUploadThree: any = true;
  isUploadFour: any = true;
  changeImageOne: boolean;
  setImageOne: boolean;
  setImageTwo: boolean;
  setImageThree: boolean;
  setImageFour: boolean;
  imageOneUrl: any = {};
  getKey: any;
  uploadOneProgress: number;
  uploadTwoProgress: number;
  uploadThreeProgress: any;
  uploadFourProgress: number;
  model: any = {};
  getdonloadUrl1: any;
  getdonloadUrl2: any;
  getdonloadUrl3: any;
  getdonloadUrl4: any;
  cureentUserObj: any;
  dbRef: any = firebase.database().ref('users');

  @ViewChild('cropper', undefined) cropper:ImageCropperComponent;

  constructor(public af: AngularFire, private upSvc: UploadService) {
    var getdonloadUrl1: any;
    this.userFolder = null;
    let that = this;
    this.af.auth.subscribe(val =>{
      this.emailAdress = val.auth.email;
      this.userId = val.auth.uid;
    });
    this.storageRef = firebase.storage().ref();
    this.cropperSettings = new CropperSettings();
    this.cropperSettings.width = 350;
    this.cropperSettings.height = 350;

    this.cropperSettings.croppedWidth = 350;
    this.cropperSettings.croppedHeight = 350;

    this.cropperSettings.canvasWidth = 500;
    this.cropperSettings.canvasHeight = 300;

    this.cropperSettings.minWidth = 10;
    this.cropperSettings.minHeight = 10;

    this.cropperSettings.rounded = false;
    this.cropperSettings.keepAspect = false;

    this.cropperSettings.cropperDrawSettings.strokeColor = 'rgba(255,255,255,1)';
    this.cropperSettings.cropperDrawSettings.strokeWidth = 2;
    this.cropperSettings.croppingClass = 'croppClass';
    this.cropperSettings.cropperClass = 'croppSetClass';

    this.dbRef.orderByChild('uid').equalTo(this.userId).once('value', function (val) {
      for (let uniqueKey in val.val()) {
        that.getKey = uniqueKey;
      }
      that.cureentUserObj = val.val()[that.getKey];
      alert(JSON.stringify(that.cureentUserObj));

      if(val.val()[that.getKey].profileImage.url1) {
        firebase.storage().ref(val.val()[that.getKey].profileImage.url1).getDownloadURL().then(function(url1) {
          that.getdonloadUrl1 = url1
        })
      }
      if(val.val()[that.getKey].profileImage.url2) {
        firebase.storage().ref(val.val()[that.getKey].profileImage.url2).getDownloadURL().then(function(url2) {
          that.getdonloadUrl2 = url2
        })
      }
      if(val.val()[that.getKey].profileImage.url3) {
        firebase.storage().ref(val.val()[that.getKey].profileImage.url3).getDownloadURL().then(function(url3) {
          that.getdonloadUrl3 = url3
        })
      }
      if(val.val()[that.getKey].profileImage.url4) {
        firebase.storage().ref(val.val()[that.getKey].profileImage.url4).getDownloadURL().then(function(url4) {
          that.getdonloadUrl4 = url4
        })
      }

  });


  }

  /**
   * Used to send image to second cropper
   * @param $event
   */
  fileChangeListener($event) {
    this.picNameOne = $event.target.value;
    this.picNameOne = this.picNameOne.replace(/^.*[\\\/]/, '');

  }
  fileChangeListenerTwo($event) {
    this.picNameTwo = $event.target.value;
    this.picNameTwo = this.picNameTwo.replace(/^.*[\\\/]/, '');
  }
  fileChangeListenerThree($event) {
    this.picNameThree = $event.target.value;
    this.picNameThree = this.picNameThree.replace(/^.*[\\\/]/, '');
  }
  fileChangeListenerFour($event) {
    this.picNameFour = $event.target.value;
    this.picNameFour = this.picNameFour.replace(/^.*[\\\/]/, '');
  }
  cropped(bounds:Bounds) {
    this.croppedHeight =bounds.bottom-bounds.top;
    this.croppedWidth = bounds.right-bounds.left;
  }

  ngOnInit() {

  }

  pushUploadOne(upload, userid, filename, getKey, thisimageOneUrl, formData) {
    let storageRef = firebase.storage().ref();
    let uploadTask = storageRef.child(`${userid}/${filename}`).putString(upload, 'data_url');
    uploadTask.on(firebase.storage.TaskEvent.STATE_CHANGED,
      (snapshot) =>  {
        // upload in progress
        this.uploadOneProgress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
        let pushThat = this;
        setTimeout(function () {
          if(pushThat.uploadOneProgress == 100){
            pushThat.isUploadOne = false;
          }
        }, 500);
      },
      (error) => {
        // upload failed
        console.log(error);
      },
      () => {
        // upload success
        thisimageOneUrl['url1'] = `/${userid}/${filename}`;
        thisimageOneUrl['name1'] = filename;
        if(formData.options == 1) {
          thisimageOneUrl['isProileImage'] = 1;
        }
        this.upSvc.saveFileData(thisimageOneUrl, getKey);
      }
    );
  }
  deleteOne(cureentUserObj){

    firebase.storage().ref(cureentUserObj.profileImage.url1).delete().then(function() {

    }).catch(function(error) {
      // Uh-oh, an error occurred!
    });
  }

  pushUploadTwo(upload, userid, filename, getKey, thisimageOneUrl, formData) {
    let storageRef = firebase.storage().ref();
    let uploadTask = storageRef.child(`${userid}/${filename}`).putString(upload, 'data_url');
    uploadTask.on(firebase.storage.TaskEvent.STATE_CHANGED,
      (snapshot) =>  {
        // upload in progress
        this.uploadTwoProgress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
        let pushThat = this;
        setTimeout(function () {
          if(pushThat.uploadTwoProgress == 100){
            pushThat.isUploadTwo = false;
          }
        }, 500);
      },
      (error) => {
        // upload failed
        console.log(error);
      },
      () => {
        // upload success
        thisimageOneUrl['url2'] = `/${userid}/${filename}`;
        thisimageOneUrl['name2'] = filename;
        if(formData.options == 2) {
          thisimageOneUrl['isProileImage'] = 2;
        }
        this.upSvc.saveFileData(thisimageOneUrl, getKey);
      }
    );
  }

  deleteTwo(cureentUserObj){

    firebase.storage().ref(cureentUserObj.profileImage.url2).delete().then(function() {

    }).catch(function(error) {
      // Uh-oh, an error occurred!
    });
  }

  deleteThree(cureentUserObj){

    firebase.storage().ref(cureentUserObj.profileImage.url3).delete().then(function() {

    }).catch(function(error) {
      // Uh-oh, an error occurred!
    });
  }

  deleteFour(cureentUserObj){

    firebase.storage().ref(cureentUserObj.profileImage.url4).delete().then(function() {

    }).catch(function(error) {
      // Uh-oh, an error occurred!
    });
  }

  pushUploadThree(upload, userid, filename, getKey, thisimageOneUrl, formData) {
    let storageRef = firebase.storage().ref();
    let uploadTask = storageRef.child(`${userid}/${filename}`).putString(upload, 'data_url');
    uploadTask.on(firebase.storage.TaskEvent.STATE_CHANGED,
      (snapshot) =>  {
        // upload in progress
        this.uploadThreeProgress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
        let pushThat = this;
        setTimeout(function () {
          if(pushThat.uploadThreeProgress == 100){
            pushThat.isUploadThree = false;
          }
        }, 500);
      },
      (error) => {
        // upload failed
        console.log(error);
      },
      () => {
        // upload success
        thisimageOneUrl['url3'] = `/${userid}/${filename}`;
        thisimageOneUrl['name3'] = filename;
        if(formData.options == 3) {
          thisimageOneUrl['isProileImage'] = 3;
        }
        this.upSvc.saveFileData(thisimageOneUrl, getKey);
      }
    );
  }

  pushUploadFour(upload, userid, filename, getKey, thisimageOneUrl, formData) {
    let storageRef = firebase.storage().ref();
    let uploadTask = storageRef.child(`${userid}/${filename}`).putString(upload, 'data_url');
    uploadTask.on(firebase.storage.TaskEvent.STATE_CHANGED,
      (snapshot) =>  {
        // upload in progress
        this.uploadFourProgress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
        let pushThat = this;
        setTimeout(function () {
          if(pushThat.uploadFourProgress == 100){
            pushThat.isUploadFour = false;
          }
        }, 500);
      },
      (error) => {
        // upload failed
        console.log(error);
      },
      () => {
        // upload success
        thisimageOneUrl['url4'] = `/${userid}/${filename}`;
        thisimageOneUrl['name4'] = filename;
        if(formData.options == 4) {
          thisimageOneUrl['isProileImage'] = 4;
        }
        this.upSvc.saveFileData(thisimageOneUrl, getKey);
      }
    );
  }


  save(formData, formValid) {
    alert(JSON.stringify(formData));
    let saveThis = this;
    let thisimageOneUrl: object = {};
    if(this.picNameOne){
      if(this.getdonloadUrl1){
          alert('1');
          this.deleteOne(this.cureentUserObj);
          this.pushUploadOne(this.imgOne.image, this.userId, this.picNameOne, this.getKey, thisimageOneUrl, formData);
      } else {
        alert('2');
        this.pushUploadOne(this.imgOne.image, this.userId, this.picNameOne, this.getKey, thisimageOneUrl, formData);
      }
    }
    if(this.picNameTwo) {
      if (this.getdonloadUrl2) {
        this.deleteTwo(this.cureentUserObj);
        this.pushUploadTwo(this.imgTwo.image, this.userId, this.picNameTwo, this.getKey, thisimageOneUrl, formData);
      }
      else {
        this.pushUploadTwo(this.imgTwo.image, this.userId, this.picNameTwo, this.getKey, thisimageOneUrl, formData);
      }
    }
    if(this.picNameThree) {
      if (this.getdonloadUrl3) {
        this.deleteThree(this.cureentUserObj);
        this.pushUploadThree(this.imgThree.image, this.userId, this.picNameThree, this.getKey, thisimageOneUrl, formData);
      }
      else {
        this.pushUploadThree(this.imgThree.image, this.userId, this.picNameThree, this.getKey, thisimageOneUrl, formData);
      }
    }
    /*if(this.picNameTwo) {
      this.pushUploadTwo(this.imgTwo.image, this.userId, this.picNameTwo, this.getKey, thisimageOneUrl, formData);
    }*/
   /* if(this.picNameThree) {
      this.pushUploadThree(this.imgThree.image, this.userId, this.picNameThree, this.getKey, thisimageOneUrl, formData);
    }*/
    if(this.picNameFour) {
      if (this.getdonloadUrl3) {
        this.deleteFour(this.cureentUserObj);
        this.pushUploadFour(this.imgFour.image, this.userId, this.picNameFour, this.getKey, thisimageOneUrl, formData);
      }
      else {
        this.pushUploadFour(this.imgFour.image, this.userId, this.picNameFour, this.getKey, thisimageOneUrl, formData);
      }

    }

  }

}

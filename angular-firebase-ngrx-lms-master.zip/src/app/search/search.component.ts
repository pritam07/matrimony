import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import {AngularFire, AuthProviders, AuthMethods, FirebaseListObservable, FirebaseObjectObservable} from "angularfire2";
import {Router} from '@angular/router';
import { moveIn, fallIn } from '../router.animations';
import {FormBuilder, FormGroup, FormControl, Validator, Validators} from '@angular/forms';
import { DatePipe } from  '@angular/common';
import 'rxjs/add/operator/startWith';
import 'rxjs/add/operator/map';
import { Subject } from 'rxjs/Subject';
import {validate} from "codelyzer/walkerFactory/walkerFn";
import {getOrderObservables} from "angularfire2/database";
@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  encapsulation: ViewEncapsulation.None,
  styleUrls: ['./search.component.scss'],
  animations: [moveIn(), fallIn()],
  host: {'[@moveIn]': ''}
})
export class SearchComponent implements OnInit {
  searchItems: FirebaseListObservable<any>;
  masterDataItems: FirebaseObjectObservable<any>;
  searchForm: FormGroup;
  fromAge: Array<any>;
  toAge:  Array<any>;
  countries: any;
  states: any;
  cityList: any;
  city: any;
  caste: any;
  casteList: any;
  religionList: any;
  religion: any;
  mothertongue: any;
  motherTongueList: any;
  maritialstatus: any;
  totalSearchList: any;
  maritialStatusList: any;
  filterAutocomplete: any;
  searchMoreCounter: any = 3;
  sortedList: any;
  searchFilter: any;
  stateCtrl: FormControl;

  constructor(public af: AngularFire, private fb: FormBuilder, private datePipe: DatePipe) {
    this.searchForm = this.fb.group({
      'fromage': [null],
      'toage': [null],
      'country': [null],
      'stateName': [null],
      'city': [null],
      'caste': [null],
      'religion': [null],
      'maritialstatus': [null],
      'mothertongue': [null]
    });
    this.fromAge = [];
    this.toAge = [];
    for(let i = 18; i < 61; i++){
      this.fromAge.push(i);
      this.toAge.push(i);
    }
    this.stateCtrl = new FormControl();
    this.masterDataItems =  af.database.object('/masterdetails');


    this.masterDataItems.subscribe(stateVal => {
      this.countries = stateVal.country;
      this.filterAutocomplete = function (filterObj) {

        return this.stateCtrl.valueChanges
          .startWith(null).map(filstate => filstate && typeof filstate === 'object' ? filstate.value : filstate)
          .map(value => value ? filterObj.filter(option => { return new RegExp(`^${value}`, 'gi').test(option.value) }) : filterObj.slice());

      };


      this.countries = this.filterAutocomplete(this.countries);
      this.casteList = this.filterAutocomplete(stateVal.caste);
      this.religionList = this.filterAutocomplete(stateVal.religion);
      this.motherTongueList = this.filterAutocomplete(stateVal.mothertongue);
      this.maritialStatusList = stateVal.maritialstatus;

      let formAgeVar= null;
      let toAgeVar = null;
      this.searchForm.valueChanges.subscribe(stateData =>{

        if(stateData.fromage && stateData.toage){
            if (stateData.fromage > stateData.toage) {
              if(formAgeVar != stateData.fromage){
                this.searchForm.controls['toage'].patchValue(this.searchForm.controls['fromage'].value, {emitEvent: false});
              }
              else if(toAgeVar){
                this.searchForm.controls['fromage'].patchValue(this.searchForm.controls['toage'].value, {emitEvent: false});
              }

            }

           formAgeVar =  stateData.fromage;
           toAgeVar = stateData.toage;
/*          if(stateData.fromage > stateData.toage){
            if(this.searchForm.controls['toage'].valueChanges.subscribe){
              alert('toage');
              this.searchForm.controls['fromage'].patchValue(this.searchForm.controls['toage'].value, { emitEvent: false });
            }
            else if(this.searchForm.controls['fromage'].valueChanges.subscribe) {

              this.searchForm.controls['toage'].patchValue(this.searchForm.controls['fromage'].value, { emitEvent: false });
            }

          }*/
        }
        if(stateData.country){
          let filterSearchArrycountry = (stateVal.states.filter(task => { return task[stateData.country.value]}));
          if(filterSearchArrycountry.length > 0){
            this.states = filterSearchArrycountry[0][stateData.country.value];
            this.states = this.filterAutocomplete(this.states);

            if(stateData.stateName) {
              let filterSearchArryState = (stateVal.city.filter(task => { return task[stateData.stateName.value]}));
              if(filterSearchArryState.length> 0){
                this.cityList = filterSearchArryState[0][stateData.stateName.value];
                this.cityList = this.filterAutocomplete(this.cityList);

              }
              else {
                //this.searchForm.controls['city'].setValue('');
                this.searchForm.controls['city'].reset(null, { emitEvent: false });
                this.cityList = null;
                //this.searchForm.controls['city'].disable({onlySelf: true, emitEvent: false});
              }

            }
            else {
              this.searchForm.controls['city'].reset(null, { emitEvent: false });
              this.cityList = null;
            }


          }
          else {
            this.searchForm.controls['stateName'].reset(null, { emitEvent: false });
            this.states = null;
            this.searchForm.controls['city'].reset(null, { emitEvent: false });
            this.cityList = null;
          }
        }
        else {
          this.searchForm.controls['stateName'].reset(null, { emitEvent: false });
          this.states = null;
          this.searchForm.controls['city'].reset(null, { emitEvent: false });
          this.cityList = null;
        }



      });

    });

  }
  displayFn(filstate: any): string {
    return filstate ? filstate.viewValue : filstate;
  };


  submit(searchData){
    this.searchFilter = {};
    if(searchData.toage || searchData.fromage) {
      if(searchData.fromage && !searchData.toage){

        this.searchItems = this.af.database.list('/users', {
          query: {
            orderByChild: 'age',
            startAt: searchData.fromage,
            endAt: 60,
          }

        });
      }
      else if (searchData.toage && !searchData.fromage) {
        this.searchItems = this.af.database.list('/users', {
          query: {
            orderByChild: 'age',
            startAt: 18,
            endAt: searchData.toage,
          }

        });
      }
      else if(searchData.toage && searchData.fromage){

        this.searchItems = this.af.database.list('/users', {
          query: {
            orderByChild: 'age',
            startAt: searchData.fromage,
            endAt: searchData.toage,
          }

        });
      }

    }
    else {
      this.searchItems = this.af.database.list('/users');
/*      console.log(JSON.stringify(this.searchItems.filter(
        task => task.email ==='pritam@gmail.com')));*/
    }
/*    this.sortedList = this.searchItems.filter(
      task => task.email ==='pritam@gmail.com');*/

    this.searchItems.subscribe(searchResult => {
      console.log(JSON.stringify(searchResult));
      this.totalSearchList = searchResult;
      this.sortedList = searchResult.slice(0,3);
      /*console.log(searchResult.filter(
        task => task.email == 'jhon@gmail.com' && searchData.city ?  task.city.value == searchData.city.value : true));*/
      this.searchFilter = { country: searchData.country? searchData.country: null, states: searchData.stateName ? searchData.stateName: null, city : searchData.city ? searchData.city: null, mothertongue: searchData.mothertongue ? searchData.mothertongue: null, religion: searchData.religion? searchData.religion: null, caste: searchData.caste ? searchData.caste : null, maritialstatus: searchData.maritialstatus ? searchData.maritialstatus : null };
      alert(JSON.stringify(this.searchFilter));

    });

  }
  onScrollDown() {
    this.searchMoreCounter = this.searchMoreCounter + 3;
    if(this.totalSearchList.length > this.sortedList.length){
      this.sortedList = this.totalSearchList.slice(0, this.searchMoreCounter);
    }

  }
  getProfileListing(searchlist) {
    console.log(searchlist);
  }
  ngOnInit() {
  }

}

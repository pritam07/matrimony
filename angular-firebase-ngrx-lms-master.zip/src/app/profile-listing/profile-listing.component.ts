import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import {AngularFire, FirebaseListObservable, FirebaseObjectObservable} from "angularfire2";
@Component({
  selector: 'app-profile-listing',
  templateUrl: './profile-listing.component.html',
  styleUrls: ['./profile-listing.component.scss']
})
export class ProfileListingComponent implements OnInit, OnDestroy  {
id: number;
private sub: any;
private listing: FirebaseListObservable<any>;
private currentUser: FirebaseListObservable<any>;
emailAdress: string;
userId: string;
shortListFbObs: FirebaseListObservable<any>;
getShoertListing: any;
  constructor(private route: ActivatedRoute, public af: AngularFire) { }

  ngOnInit() {
    this.shortListFbObs = this.af.database.list('/shortlist');    
    this.listing = this.af.database.list('/users');   
    this.sub = this.route.params.subscribe(params => {
       this.id = +params['id']; // (+) converts string 'id' to a number
       this.listing =  this.af.database.list('/users', {
          preserveSnapshot: true,
          query: {
            orderByChild: 'targetid',
            equalTo: this.id
          }
    });
    console.log(this.listing);

       // In a real app: dispatch action to load the details here.
    });
    this.af.auth.subscribe(val =>{
      this.emailAdress = val.auth.email;
      this.userId = val.auth.uid;
    });
  }
  shortlist(userUid){
   
      alert(userUid);
      
       this.getShoertListing = this.af.database.list('/shortlist'), {
          preserveSnapshot: true,
          query: {
            orderByChild: 'uid',
            equalTo: userUid
          }
        };
       if(this.getShoertListing){
          this.getShoertListing.subscribe(getVal => {
         alert(getVal[0]);
        if(getVal.length == 0) {
          this.shortListFbObs.push({uid: userUid});    
         }
        })
       }
       
         // alert(JSON.stringify(this.getlisting));    
        
        
  
      
    //  this.shortList.subscribe(val => {
        
    //  });
      
    //   this.currentUser = this.af.database.list('/users', {
    //       preserveSnapshot: true,
    //       query: {
    //         orderByChild: 'uid',
    //         equalTo: this.userId
    //       }
    // });
   
  }
  ngOnDestroy() {
    this.sub.unsubscribe();
  }

}

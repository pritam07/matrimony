import { Component, OnInit } from '@angular/core';
import { AngularFire, AuthProviders, AuthMethods,FirebaseListObservable } from 'angularfire2';
import { Router } from '@angular/router';
import * as firebase from 'firebase';
import {forEach} from "@angular/router/src/utils/collection";
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  items: FirebaseListObservable<any>;
  name: any;
  msgVal: string = '';
  preferenceDbRef: any;
  preferenceObjArray: any = [];
  userId: any;
  emailAdress: any;
  userDbRef: any;
  searchFilter: any = {};
  languages: any;
  filter: any;
  getDemoList: any;
  getSmallDemoList: any;
  nwFilter: any;
  constructor(public af: AngularFire, private router: Router) {
    var that = this;
    this.getSmallDemoList = [{precity: "kolkata"}, {precity: "lucknow"}, {precity: "asansol"}];
    this.nwFilter = { precity: { $or: ["asansol", "kolkata"] } };
    this.getDemoList = [{ "age": 18, "caste": { "value": "intercaste", "viewValue": "Intercaste" }, "city": { "value": " kolkata", "viewValue": "Kolkata" }, "cityName": { "value": "asansol", "viewValue": "Asansol" }, "country": { "value": "india", "viewValue": "India" }, "countryName": { "value": "india", "viewValue": "India" }, "createdby": { "value": "widowwidower", "viewValue": "Sibling" }, "dob": "Wednesday, July 7, 1999", "email": "son@gmail.com", "firstName": "dfd", "gender": { "value": "female", "viewValue": "Female" }, "lastName": "dffdf", "maritialstatus": { "value": "divorced", "viewValue": "Divorced" }, "mothertongue": { "value": "marwari", "viewValue": "Marwari" }, "path": "/P5icnMxwGGaZNrI2xtL06dDYcgf2/email.png", "profileimage": "email.png", "religion": { "value": "muslimsuni", "viewValue": "Muslim-Sunni" }, "stateName": { "value": "westbengal", "viewValue": "West Bengal" }, "states": { "value": "westbengal", "viewValue": "West Bengal" }, "uid": "P5icnMxwGGaZNrI2xtL06dDYcgf2", "updatedOn": "Friday, July 14, 2017", "userImage": [ { "path": "/P5icnMxwGGaZNrI2xtL06dDYcgf2/email.png", "profileimage": "email.png" } ], "precaste": "intercaste", "precity": " kolkata", "precityName": "asansol", "precountry": "india", "precountryName": "india", "precreatedby": "widowwidower", "pregender": "female", "premaritialstatus": "divorced", "premothertongue": "marwari", "prereligion": "muslimsuni", "prestateName": "westbengal", "prestates": "westbengal" }, { "age": 22, "caste": { "value": "ahom", "viewValue": "Ahom" }, "city": { "value": "lucknow", "viewValue": "Lucknow" }, "country": { "value": "india", "viewValue": "India" }, "createdOn": "Monday, July 10, 2017", "createdby": { "value": "self", "viewValue": "Self" }, "dob": "Wednesday, June 7, 1995", "email": "ami@gmail.com", "firstName": "ami", "gender": { "value": "male", "viewValue": "Male" }, "lastName": "jackson", "maritialstatus": { "value": "nevermarried", "viewValue": "Never Married" }, "mothertongue": { "value": "bengali", "viewValue": "Bengali" }, "religion": { "value": "hindu", "viewValue": "Hindu" }, "states": { "value": "uttarpradesh", "viewValue": "Uttar Pradesh" }, "uid": "q0qMZ3FAQcThvtqA9X7tXKVtVCF2", "updatedOn": "Monday, July 10, 2017", "precaste": "ahom", "precity": "lucknow", "precountry": "india", "precreatedby": "self", "pregender": "male", "premaritialstatus": "nevermarried", "premothertongue": "bengali", "prereligion": "hindu", "prestates": "uttarpradesh" }, { "age": 18, "caste": { "value": "ahom", "viewValue": "Ahom" }, "city": { "value": "kanpur", "viewValue": "Kanpur" }, "country": { "value": "india", "viewValue": "India" }, "createdOn": "Monday, July 10, 2017", "createdby": { "value": "parent", "viewValue": "Parent" }, "dob": "Tuesday, March 2, 1999", "email": "jamil@gmail.com", "firstName": "jamil", "gender": { "value": "female", "viewValue": "Female" }, "lastName": "jamil", "maritialstatus": { "value": "nevermarried", "viewValue": "Never Married" }, "mothertongue": { "value": "marwari", "viewValue": "Marwari" }, "religion": { "value": "muslimshia", "viewValue": "Muslim-Shia" }, "states": { "value": "uttarpradesh", "viewValue": "Uttar Pradesh" }, "uid": "QiE3myJE7mQiY2N2vc4btiLNgOJ2", "updatedOn": "Monday, July 10, 2017", "precaste": "ahom", "precity": "kanpur", "precountry": "india", "precreatedby": "parent", "pregender": "female", "premaritialstatus": "nevermarried", "premothertongue": "marwari", "prereligion": "muslimshia", "prestates": "uttarpradesh" }, { "age": 24, "caste": { "value": "intercaste", "viewValue": "Intercaste" }, "city": { "value": " kolkata", "viewValue": "Kolkata" }, "country": { "value": "india", "viewValue": "India" }, "createdOn": "Monday, July 10, 2017", "createdby": { "value": "brother", "viewValue": "Brother" }, "dob": "Tuesday, February 2, 1993", "email": "demon@gmail.com", "firstName": "demon", "gender": { "value": "female", "viewValue": "Female" }, "lastName": "demon", "maritialstatus": { "value": "awaitingdivorce", "viewValue": "Awaiting Divorce" }, "mothertongue": { "value": "marwari", "viewValue": "Marwari" }, "religion": { "value": "muslimsuni", "viewValue": "Muslim-Sunni" }, "states": { "value": "westbengal", "viewValue": "West Bengal" }, "uid": "3CVMKjA9RkX25KD6kH3qVtcO7zx1", "updatedOn": "Monday, July 10, 2017", "precaste": "intercaste", "precity": " kolkata", "precountry": "india", "precreatedby": "brother", "pregender": "female", "premaritialstatus": "awaitingdivorce", "premothertongue": "marwari", "prereligion": "muslimsuni", "prestates": "westbengal" }, { "age": 24, "caste": { "value": "brahminothers", "viewValue": "Brahmin-Others" }, "city": { "value": "lucknow", "viewValue": "Lucknow" }, "country": { "value": "india", "viewValue": "India" }, "createdOn": "Monday, July 10, 2017", "createdby": { "value": "brother", "viewValue": "Brother" }, "dob": "Tuesday, January 12, 1993", "email": "sahil@gmail.com", "firstName": "sahil", "gender": { "value": "female", "viewValue": "Female" }, "lastName": "das", "maritialstatus": { "value": "divorced", "viewValue": "Divorced" }, "mothertongue": { "value": "marwari", "viewValue": "Marwari" }, "religion": { "value": "muslimothers", "viewValue": "Muslim-Sunni" }, "states": { "value": "uttarpradesh", "viewValue": "Uttar Pradesh" }, "uid": "H071hAXcbGMCRc1zFsmEpbGmWDq2", "updatedOn": "Monday, July 10, 2017", "precaste": "brahminothers", "precity": "lucknow", "precountry": "india", "precreatedby": "brother", "pregender": "female", "premaritialstatus": "divorced", "premothertongue": "marwari", "prereligion": "muslimothers", "prestates": "uttarpradesh" }, { "age": 36, "caste": { "value": "kalita", "viewValue": "Kalita" }, "city": { "value": "asansol", "viewValue": "Asansol" }, "country": { "value": "india", "viewValue": "India" }, "createdOn": "Monday, July 10, 2017", "createdby": { "value": "brother", "viewValue": "Brother" }, "dob": "Thursday, September 3, 1981", "email": "beta@gmail.com", "firstName": "beta", "gender": { "value": "female", "viewValue": "Female" }, "lastName": "beta", "maritialstatus": { "value": "awaitingdivorce", "viewValue": "Awaiting Divorce" }, "mothertongue": { "value": "english", "viewValue": "English" }, "religion": { "value": "muslimothers", "viewValue": "Muslim-Sunni" }, "states": { "value": "westbengal", "viewValue": "West Bengal" }, "uid": "12TeEXdpgwWRHfqv9UGLNTOZfvL2", "updatedOn": "Monday, July 10, 2017", "precaste": "kalita", "precity": "asansol", "precountry": "india", "precreatedby": "brother", "pregender": "female", "premaritialstatus": "awaitingdivorce", "premothertongue": "english", "prereligion": "muslimothers", "prestates": "westbengal" }, { "age": 27, "caste": { "value": "kalita", "viewValue": "Kalita" }, "city": { "value": "lucknow", "viewValue": "Lucknow" }, "country": { "value": "india", "viewValue": "India" }, "createdOn": "Monday, July 10, 2017", "createdby": { "value": "brother", "viewValue": "Brother" }, "dob": "Wednesday, February 14, 1990", "email": "malay@gmail.com", "firstName": "malay", "gender": { "value": "female", "viewValue": "Female" }, "lastName": "das", "maritialstatus": { "value": "awaitingdivorce", "viewValue": "Awaiting Divorce" }, "mothertongue": { "value": "marwari", "viewValue": "Marwari" }, "religion": { "value": "muslimsuni", "viewValue": "Muslim-Sunni" }, "states": { "value": "uttarpradesh", "viewValue": "Uttar Pradesh" }, "uid": "zWfW8aIXzfSdiS53D2EZRta53rw2", "updatedOn": "Monday, July 10, 2017", "precaste": "kalita", "precity": "lucknow", "precountry": "india", "precreatedby": "brother", "pregender": "female", "premaritialstatus": "awaitingdivorce", "premothertongue": "marwari", "prereligion": "muslimsuni", "prestates": "uttarpradesh" }, { "age": 21, "caste": { "value": "brahminothers", "viewValue": "Brahmin-Others" }, "city": { "value": " kolkata", "viewValue": "Kolkata" }, "country": { "value": "india", "viewValue": "India" }, "createdOn": "7/19/2017, 7:48 PM", "createdby": { "value": "brother", "viewValue": "Brother" }, "dob": "7/2/1996", "email": "pritam@gmail.com", "firstName": "pritam", "gender": { "value": "male", "viewValue": "Male" }, "lastName": "modok", "maritialstatus": { "value": "divorced", "viewValue": "Divorced" }, "mothertongue": { "value": "hindi", "viewValue": "Hindi" }, "religion": { "value": "muslimshia", "viewValue": "Muslim-Shia" }, "sourceid": "IN697622837", "states": { "value": "westbengal", "viewValue": "West Bengal" }, "targetid": 241269572, "uid": "MVDFl7phrDYBhr7Uga9HPNi5sSp1", "precaste": "brahminothers", "precity": " kolkata", "precountry": "india", "precreatedby": "brother", "pregender": "male", "premaritialstatus": "divorced", "premothertongue": "hindi", "prereligion": "muslimshia", "prestates": "westbengal" }, { "age": 21, "caste": { "value": "brahminothers", "viewValue": "Brahmin-Others" }, "city": { "value": " kolkata", "viewValue": "Kolkata" }, "country": { "value": "india", "viewValue": "India" }, "createdOn": "7/20/2017, 2:45 AM", "createdby": { "value": "widowwidower", "viewValue": "Sibling" }, "dob": "7/2/1996", "email": "men@gmail.com", "firstName": "men", "gender": { "value": "male", "viewValue": "Male" }, "lastName": "MenLast", "maritialstatus": { "value": "nevermarried", "viewValue": "Never Married" }, "mothertongue": { "value": "hindi", "viewValue": "Hindi" }, "religion": { "value": "muslimshia", "viewValue": "Muslim-Shia" }, "sourceid": "IN123", "states": { "value": "westbengal", "viewValue": "West Bengal" }, "targetid": "123", "uid": "RTplFn4uIkQSLcOsTGEffjWtXvJ3", "precaste": "brahminothers", "precity": " kolkata", "precountry": "india", "precreatedby": "widowwidower", "pregender": "male", "premaritialstatus": "nevermarried", "premothertongue": "hindi", "prereligion": "muslimshia", "prestates": "westbengal" }, { "age": 18, "caste": { "value": "intercaste", "viewValue": "Intercaste" }, "city": { "value": " kolkata", "viewValue": "Kolkata" }, "country": { "value": "india", "viewValue": "India" }, "createdOn": "7/20/2017, 1:46 PM", "createdby": { "value": "brother", "viewValue": "Brother" }, "dob": "7/7/1999", "email": "women@gmail.com", "firstName": "sdsd", "gender": { "value": "female", "viewValue": "Female" }, "lastName": "sdds", "maritialstatus": { "value": "awaitingdivorce", "viewValue": "Awaiting Divorce" }, "mothertongue": { "value": "hindi", "viewValue": "Hindi" }, "religion": { "value": "muslimsuni", "viewValue": "Muslim-Sunni" }, "sourceid": "IN522550871", "states": { "value": "westbengal", "viewValue": "West Bengal" }, "targetid": 490794817, "uid": "ixe7V7fBgqU4a9Y9pHV3fHdf3lF2", "updatedOn": "7/20/2017, 3:22 PM", "precaste": "intercaste", "precity": " kolkata", "precountry": "india", "precreatedby": "brother", "pregender": "female", "premaritialstatus": "awaitingdivorce", "premothertongue": "hindi", "prereligion": "muslimsuni", "prestates": "westbengal" }, { "age": 21, "caste": { "value": "brahminothers", "viewValue": "Brahmin-Others" }, "city": { "value": " kolkata", "viewValue": "Kolkata" }, "country": { "value": "india", "viewValue": "India" }, "createdOn": "7/20/2017, 3:37 PM", "createdby": { "value": "widowwidower", "viewValue": "Sibling" }, "dob": "7/11/1996", "email": "new@gmail.com", "firstName": "new", "gender": { "value": "male", "viewValue": "Male" }, "lastName": "newLast", "maritialstatus": { "value": "divorced", "viewValue": "Divorced" }, "mothertongue": { "value": "hindi", "viewValue": "Hindi" }, "religion": { "value": "muslimshia", "viewValue": "Muslim-Shia" }, "sourceid": "IN181390890", "states": { "value": "westbengal", "viewValue": "West Bengal" }, "targetid": 954373212, "uid": "TMrb8F0oR6SQra5Qdy9HCB31stE3", "precaste": "brahminothers", "precity": " kolkata", "precountry": "india", "precreatedby": "widowwidower", "pregender": "male", "premaritialstatus": "divorced", "premothertongue": "hindi", "prereligion": "muslimshia", "prestates": "westbengal" } ];
    this.languages = [
      { language: 'English',
        city: {
        "value": "asansol",
        "viewValue": "Asansol"
      }
      },
      { language: 'German',  city: {
        "value": "kolkata",
        "viewValue": "kolkata"
      }  },
      { language: 'Italian', city: {
        "value": "delhi",
        "viewValue": "delhi"
      }  }
    ];

// your $or filter
    this.filter = {
      age: {
        $or: [50, 18]
      }
    };


    this.items = af.database.list('/messages', {
      query: {
        limitToLast: 2
      }
    });
    var userId = null;
    var userDbRef = firebase.database().ref('users');
    var preferenceObj = null;
    var pushPreferecne = [];
    var getPreferenceKey = {};
    var getPreferenceKeyFinal = {};

    this.af.auth.subscribe(auth => {
      if(auth) {
        this.name = auth;
        this.userId = auth.auth.uid;
        this.emailAdress = auth.auth.email;
        userId = auth.auth.uid;

      }
    });

    let getPreference = function () {

      userDbRef.on('child_added', function (searchVal) {
      /*  alert(JSON.stringify(searchVal.val()));*/
      let thisSearchVal = searchVal.val();


        for(let snapKey in thisSearchVal){
          if((typeof thisSearchVal[snapKey]) === 'object'){
            thisSearchVal['pre' + snapKey] = thisSearchVal[snapKey].value;
          }
        }
        that.preferenceObjArray.push(thisSearchVal);

      });
      /*if(preferenceObj !=null){
        this.preferenceObj = preferenceObj;
        alert(this.preferenceObj);
      }*/
    };
    this.preferenceDbRef = firebase.database().ref('preference');
    this.userDbRef = firebase.database().ref('users');



    this.preferenceDbRef.orderByChild('uid').equalTo(this.userId).once('value', function (val) {
    /*  alert(val.key);
      alert(val.val().getKey);
      console.log(val.val());*/
     let currentUserList = val.val();

      for(let userKey in currentUserList) {
       // alert(currentUserList.numChildren());
      //  alert('1');
        var getUserKey = userKey;

         currentUserList = currentUserList[userKey];
      }
      if(val.child(getUserKey).hasChildren()){
        val.child(getUserKey).forEach(function (cildVal) {
          if(cildVal.numChildren() > 1){
            pushPreferecne = [];
            cildVal.forEach(function (childSnapshot) {
              pushPreferecne.push(childSnapshot.val().value);
              getPreferenceKey = {$or : pushPreferecne};
              that.searchFilter['pre' + cildVal["key"]] = getPreferenceKey;
             /* childSnapshot.key = {$or : pushPreferecne};*/
            /*  alert(JSON.stringify({$or : pushPreferecne}));*/
             // that.searchFilter[cildVal.key] = {$or : pushPreferecne};
             // alert(JSON.stringify(that.searchFilter));
            })
          }
          else if(cildVal.numChildren()==1){
            that.searchFilter[cildVal["key"]] = cildVal.val()[0];
            //that.searchFilter[cildVal["key"]] =
          }

        })
      }

     // alert(val.child(getUserKey).numChildren());


        for(let key in currentUserList){
         // alert(Object.keys(currentUserList[key]).length) ;

          /*if(typeof currentUserList[key]) {
            alert(JSON.stringify(currentUserList[key]));
          }*/
        }
        getPreference();
     // that.searchFilter = { country: currentUserList.country? currentUserList.country: null, states: currentUserList.stateName ? currentUserList.stateName: null, city : currentUserList.city ? currentUserList.city: null, mothertongue: currentUserList.mothertongue ? currentUserList.mothertongue: null, religion: currentUserList.religion? currentUserList.religion: null, caste: currentUserList.caste ? currentUserList.caste : null, maritialstatus: currentUserList.maritialstatus ? currentUserList.maritialstatus : null };

    });




  }

  Send(desc: string) {
    this.items.push({ message: desc});
    this.msgVal = '';
  }


  ngOnInit() {
  }

}
